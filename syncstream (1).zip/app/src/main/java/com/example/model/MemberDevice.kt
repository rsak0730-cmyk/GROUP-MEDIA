package com.example.model

data class MemberDevice(
    val id: String,
    val deviceName: String,
    val ipAddress: String,
    val latencyMs: Long = 0,
    val volume: Float = 1.0f,
    val isMuted: Boolean = false,
    val isSynced: Boolean = true,
    val joinedAt: Long = System.currentTimeMillis()
)
