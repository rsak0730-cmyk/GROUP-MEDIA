package com.example.model

data class AudioTrackItem(
    val id: String,
    val title: String,
    val artist: String,
    val durationMs: Long,
    val bpm: Int = 128,
    val genre: String = "Electronic",
    val synthPresetName: String? = null,
    val uriString: String? = null
)

val SampleAudioTracks = listOf(
    AudioTrackItem(
        id = "track_1",
        title = "Neon Horizon (Synthwave)",
        artist = "SoundSync Audio Core",
        durationMs = 184000L,
        bpm = 120,
        genre = "Synthwave",
        synthPresetName = "SYNTH_NEON"
    ),
    AudioTrackItem(
        id = "track_2",
        title = "Midnight Club (Bass Pulse)",
        artist = "Cyber Echo",
        durationMs = 210000L,
        bpm = 128,
        genre = "Bass House",
        synthPresetName = "SYNTH_BASS"
    ),
    AudioTrackItem(
        id = "track_3",
        title = "Chilled Glass (Lofi Beat)",
        artist = "Crystal Harmony",
        durationMs = 165000L,
        bpm = 85,
        genre = "Lofi Hip-Hop",
        synthPresetName = "SYNTH_LOFI"
    ),
    AudioTrackItem(
        id = "track_4",
        title = "Acoustic Multi-Room Sync Test",
        artist = "Phase Calibration Tone",
        durationMs = 120000L,
        bpm = 100,
        genre = "Audio Calibration",
        synthPresetName = "SYNTH_PULSE"
    )
)
