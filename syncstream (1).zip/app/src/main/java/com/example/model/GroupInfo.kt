package com.example.model

import org.json.JSONObject

data class GroupInfo(
    val groupId: String,
    val hostName: String,
    val hostIp: String,
    val port: Int = 8888,
    val streamPort: Int = 8889,
    val ssid: String = "Wi-Fi Network",
    val createdAt: Long = System.currentTimeMillis()
) {
    fun toJson(): String {
        return JSONObject().apply {
            put("type", "SOUNDSYNC_GROUP")
            put("groupId", groupId)
            put("hostName", hostName)
            put("hostIp", hostIp)
            put("port", port)
            put("streamPort", streamPort)
            put("ssid", ssid)
            put("createdAt", createdAt)
        }.toString()
    }

    companion object {
        fun fromJson(jsonStr: String): GroupInfo? {
            return try {
                val obj = JSONObject(jsonStr)
                if (obj.optString("type") == "SOUNDSYNC_GROUP" || obj.has("hostIp")) {
                    GroupInfo(
                        groupId = obj.optString("groupId", "GRP-${System.currentTimeMillis() % 10000}"),
                        hostName = obj.optString("hostName", "Host Device"),
                        hostIp = obj.getString("hostIp"),
                        port = obj.optInt("port", 8888),
                        streamPort = obj.optInt("streamPort", 8889),
                        ssid = obj.optString("ssid", "Local Network"),
                        createdAt = obj.optLong("createdAt", System.currentTimeMillis())
                    )
                } else null
            } catch (e: Exception) {
                null
            }
        }
    }
}
