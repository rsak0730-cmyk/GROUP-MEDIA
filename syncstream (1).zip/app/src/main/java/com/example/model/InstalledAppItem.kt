package com.example.model

import android.graphics.drawable.Drawable

data class InstalledAppItem(
    val packageName: String,
    val appName: String,
    val icon: Drawable? = null,
    val isMediaCategory: Boolean = false,
    val isSelected: Boolean = false
)
