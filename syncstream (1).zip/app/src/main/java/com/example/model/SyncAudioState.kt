package com.example.model

enum class PlaybackState {
    PLAYING,
    PAUSED,
    STOPPED
}

enum class AudioSourceType(val displayName: String) {
    BUILTIN_TRACK("Built-in Studio Track"),
    SYNTHESIZER("Synced Tone Synth"),
    LIVE_MIC("Live Mic Broadcaster"),
    LOCAL_FILE("Local Music File"),
    EXTERNAL_APP("External App Audio")
}

data class SyncAudioState(
    val playbackState: PlaybackState = PlaybackState.STOPPED,
    val currentTrackTitle: String = "Neon Horizon - Synthwave",
    val currentTrackArtist: String = "SoundSync Audio Core",
    val currentTrackDurationMs: Long = 180000L,
    val playbackPositionMs: Long = 0L,
    val masterVolume: Float = 0.85f,
    val sourceType: AudioSourceType = AudioSourceType.BUILTIN_TRACK,
    val selectedAppPackage: String? = null,
    val selectedAppName: String? = null,
    val isMicBroadcasting: Boolean = false,
    val timestampSentMs: Long = System.currentTimeMillis(),
    val masterClockNtp: Long = System.currentTimeMillis()
)
