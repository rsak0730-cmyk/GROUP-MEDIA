package com.example.audio

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaPlayer
import android.media.MediaRecorder
import android.net.Uri
import android.os.Build
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.File
import kotlin.math.sin

class AudioSyncEngine(
    private val context: Context,
    private val onAmplitudeChanged: (Float) -> Unit,
    private val onSynthTick: (Int, Double) -> Unit
) {
    private val tag = "AudioSyncEngine"
    private val sampleRate = 44100
    private var synthJob: Job? = null
    private var micRecordJob: Job? = null
    private var mediaPlayer: MediaPlayer? = null
    private val scope = CoroutineScope(Dispatchers.Default)

    var acousticLatencyOffsetMs: Int = 0
    var localVolume: Float = 0.9f
        set(value) {
            field = value.coerceIn(0f, 1f)
            mediaPlayer?.setVolume(field, field)
        }

    // Synth Melody Scales
    private val synthScaleA = doubleArrayOf(220.0, 261.63, 293.66, 329.63, 392.0, 440.0, 523.25, 659.25)
    private val synthBassLine = doubleArrayOf(110.0, 110.0, 146.83, 146.83, 164.81, 164.81, 130.81, 130.81)

    fun startSynthPlayback(presetName: String = "SYNTH_NEON", onStep: (Double) -> Unit) {
        stopSynth()
        synthJob = scope.launch {
            var step = 0
            val noteDurationMs = when (presetName) {
                "SYNTH_BASS" -> 234L // 128 BPM eighth notes
                "SYNTH_LOFI" -> 352L // 85 BPM eighth notes
                "SYNTH_PULSE" -> 300L
                else -> 250L // 120 BPM
            }

            while (isActive) {
                val freq = when (presetName) {
                    "SYNTH_BASS" -> synthBassLine[step % synthBassLine.size]
                    "SYNTH_LOFI" -> synthScaleA[(step * 2) % synthScaleA.size] * 0.75
                    "SYNTH_PULSE" -> if (step % 4 == 0) 880.0 else 440.0
                    else -> synthScaleA[step % synthScaleA.size]
                }

                playToneAsync(freq, (noteDurationMs * 0.8).toLong())
                onSynthTick(step, freq)
                onStep(freq)
                step++

                val delayWithOffset = (noteDurationMs + (acousticLatencyOffsetMs / 4)).coerceAtLeast(50)
                delay(delayWithOffset)
            }
        }
    }

    fun stopSynth() {
        synthJob?.cancel()
        synthJob = null
        onAmplitudeChanged(0f)
    }

    fun playSingleTone(freq: Double, durationMs: Long) {
        scope.launch {
            playToneAsync(freq, durationMs)
        }
    }

    private fun playToneAsync(freq: Double, durationMs: Long) {
        try {
            val numSamples = (sampleRate * (durationMs / 1000.0)).toInt().coerceAtLeast(1)
            val buffer = ShortArray(numSamples)
            val decay = numSamples.toDouble()

            for (i in 0 until numSamples) {
                // Sine wave with soft attack and exponential decay
                val envelope = 1.0 - (i / decay)
                val angle = 2.0 * Math.PI * i / (sampleRate / freq)
                val sample = (sin(angle) * Short.MAX_VALUE * envelope * localVolume * 0.8).toInt()
                buffer[i] = sample.coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt()).toShort()
            }

            val audioTrack = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                AudioTrack.Builder()
                    .setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_MEDIA)
                            .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                            .build()
                    )
                    .setAudioFormat(
                        AudioFormat.Builder()
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setSampleRate(sampleRate)
                            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                            .build()
                    )
                    .setBufferSizeInBytes(buffer.size * 2)
                    .setTransferMode(AudioTrack.MODE_STATIC)
                    .build()
            } else {
                @Suppress("DEPRECATION")
                AudioTrack(
                    AudioManager.STREAM_MUSIC,
                    sampleRate,
                    AudioFormat.CHANNEL_OUT_MONO,
                    AudioFormat.ENCODING_PCM_16BIT,
                    buffer.size * 2,
                    AudioTrack.MODE_STATIC
                )
            }

            audioTrack.write(buffer, 0, buffer.size)
            audioTrack.play()

            // Visualizer amplitude pulse
            onAmplitudeChanged((freq / 800.0).toFloat().coerceIn(0.3f, 0.95f))

            scope.launch {
                delay(durationMs)
                try {
                    audioTrack.stop()
                    audioTrack.release()
                    onAmplitudeChanged(0.1f)
                } catch (_: Exception) {}
            }
        } catch (e: Exception) {
            Log.e(tag, "Error playing tone: ${e.message}")
        }
    }

    fun playLocalAudio(uri: Uri, onCompletion: () -> Unit) {
        stopAll()
        try {
            mediaPlayer = MediaPlayer().apply {
                setDataSource(context, uri)
                setVolume(localVolume, localVolume)
                prepare()
                start()
                setOnCompletionListener {
                    onCompletion()
                }
            }
        } catch (e: Exception) {
            Log.e(tag, "Failed to play audio URI: ${e.message}")
        }
    }

    fun startLiveMicBroadcast(onMicChunk: (ByteArray) -> Unit) {
        stopMicBroadcast()
        micRecordJob = scope.launch(Dispatchers.IO) {
            try {
                val minBufSize = AudioRecord.getMinBufferSize(
                    sampleRate,
                    AudioFormat.CHANNEL_IN_MONO,
                    AudioFormat.ENCODING_PCM_16BIT
                )
                val bufferSize = minBufSize.coerceAtLeast(4096)
                val audioRecord = AudioRecord(
                    MediaRecorder.AudioSource.MIC,
                    sampleRate,
                    AudioFormat.CHANNEL_IN_MONO,
                    AudioFormat.ENCODING_PCM_16BIT,
                    bufferSize
                )

                audioRecord.startRecording()
                val audioBuffer = ByteArray(1024)

                while (isActive && audioRecord.recordingState == AudioRecord.RECORDSTATE_RECORDING) {
                    val read = audioRecord.read(audioBuffer, 0, audioBuffer.size)
                    if (read > 0) {
                        onMicChunk(audioBuffer.copyOf(read))

                        // Compute RMS amplitude for visualizer
                        var sum = 0.0
                        for (i in 0 until read step 2) {
                            if (i + 1 < read) {
                                val sample = (audioBuffer[i + 1].toInt() shl 8) or (audioBuffer[i].toInt() and 0xFF)
                                sum += sample * sample
                            }
                        }
                        val rms = Math.sqrt(sum / (read / 2)) / 32768.0
                        onAmplitudeChanged(rms.toFloat().coerceIn(0f, 1f))
                    }
                }

                audioRecord.stop()
                audioRecord.release()
            } catch (e: Exception) {
                Log.e(tag, "Mic broadcast error: ${e.message}")
            }
        }
    }

    fun stopMicBroadcast() {
        micRecordJob?.cancel()
        micRecordJob = null
        onAmplitudeChanged(0f)
    }

    fun stopAll() {
        stopSynth()
        stopMicBroadcast()
        try {
            mediaPlayer?.stop()
            mediaPlayer?.release()
            mediaPlayer = null
        } catch (_: Exception) {}
    }
}
