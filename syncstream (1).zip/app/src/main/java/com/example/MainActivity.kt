package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.AppScreen
import com.example.ui.CheerEvent
import com.example.ui.SoundSyncViewModel
import com.example.ui.screens.AppSelectorSheet
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.HostScreen
import com.example.ui.screens.JoinScreen
import com.example.ui.screens.MemberSyncedScreen
import com.example.ui.theme.GlassBackgroundDeep
import com.example.ui.theme.SoundSyncTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            SoundSyncTheme {
                SoundSyncApp()
            }
        }
    }
}

@Composable
fun SoundSyncApp(
    viewModel: SoundSyncViewModel = viewModel()
) {
    val uiState by viewModel.uiState.collectAsState()
    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(uiState.statusMessage) {
        uiState.statusMessage?.let { msg ->
            snackbarHostState.showSnackbar(msg)
            viewModel.clearStatusMessage()
        }
    }

    // Handle Back Press
    BackHandler(enabled = uiState.currentScreen != AppScreen.HOME) {
        if (uiState.currentScreen == AppScreen.CREATE_GROUP ||
            uiState.currentScreen == AppScreen.MEMBER_SYNCED
        ) {
            viewModel.disconnectAndReset()
        } else {
            viewModel.navigateTo(AppScreen.HOME)
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(GlassBackgroundDeep)
    ) {
        when (uiState.currentScreen) {
            AppScreen.HOME -> {
                HomeScreen(
                    uiState = uiState,
                    onCreateGroupClick = { viewModel.createGroup() },
                    onJoinGroupClick = { viewModel.startJoinGroup() },
                    onOpenAppSelector = { viewModel.setAppSelectorVisible(true) },
                    onRefreshNetwork = { viewModel.refreshNetworkInfo() }
                )
            }
            AppScreen.CREATE_GROUP -> {
                HostScreen(
                    uiState = uiState,
                    onDisconnectClick = { viewModel.disconnectAndReset() },
                    onTogglePlayPause = { viewModel.togglePlayPause() },
                    onSelectTrack = { idx -> viewModel.selectTrack(idx) },
                    onVolumeChange = { vol -> viewModel.setMasterVolume(vol) },
                    onToggleMic = { viewModel.toggleMicBroadcast() },
                    onOpenAppSelector = { viewModel.setAppSelectorVisible(true) },
                    onSendCheer = { emoji -> viewModel.sendCheer(emoji) }
                )
            }
            AppScreen.JOIN_GROUP -> {
                JoinScreen(
                    uiState = uiState,
                    onBackClick = { viewModel.navigateTo(AppScreen.HOME) },
                    onQrScanned = { raw -> viewModel.onQrScanned(raw) },
                    onManualConnect = { ip, port -> viewModel.connectToHost(ip, port) }
                )
            }
            AppScreen.MEMBER_SYNCED -> {
                MemberSyncedScreen(
                    uiState = uiState,
                    onDisconnectClick = { viewModel.disconnectAndReset() },
                    onLocalVolumeChange = { vol -> viewModel.setMasterVolume(vol) },
                    onAcousticOffsetChange = { offset -> viewModel.setAcousticOffset(offset) },
                    onSendCheer = { emoji -> viewModel.sendCheer(emoji) }
                )
            }
        }

        // Floating Cheer Reaction Overlay
        uiState.activeCheers.forEach { cheer ->
            FloatingCheerItem(cheer = cheer)
        }

        // App Selector Modal Bottom Sheet
        if (uiState.isAppSelectorVisible) {
            AppSelectorSheet(
                installedApps = uiState.installedApps,
                selectedPackage = uiState.audioState.selectedAppPackage,
                onAppSelected = { app -> viewModel.selectExternalApp(app) },
                onDismiss = { viewModel.setAppSelectorVisible(false) }
            )
        }

        SnackbarHost(
            hostState = snackbarHostState,
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 32.dp)
        )
    }
}

@Composable
fun FloatingCheerItem(cheer: CheerEvent) {
    val yOffset = remember { Animatable(0f) }
    val alpha = remember { Animatable(1f) }
    val randomX = remember(cheer.id) { ((cheer.id % 200) - 100).toInt() }

    LaunchedEffect(cheer.id) {
        yOffset.animateTo(-300f, animationSpec = tween(1600))
    }
    LaunchedEffect(cheer.id) {
        alpha.animateTo(0f, animationSpec = tween(1600))
    }

    Box(
        modifier = Modifier
            .fillMaxSize(),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = cheer.emoji,
            fontSize = 42.sp,
            modifier = Modifier
                .offset { IntOffset(randomX, yOffset.value.toInt()) }
                .background(Color.Transparent)
        )
    }
}
