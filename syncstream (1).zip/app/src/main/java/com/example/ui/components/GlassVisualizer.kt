package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.ui.theme.AccentCyan
import com.example.ui.theme.AccentNeonBlue
import com.example.ui.theme.AccentPink
import com.example.ui.theme.AccentPurple
import kotlin.math.sin

@Composable
fun GlassAudioVisualizerBars(
    isPlaying: Boolean,
    amplitude: Float = 0.5f,
    modifier: Modifier = Modifier,
    barCount: Int = 24,
    height: Dp = 64.dp
) {
    val infiniteTransition = rememberInfiniteTransition(label = "visualizer")
    val phase by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = (2 * Math.PI).toFloat(),
        animationSpec = infiniteRepeatable(
            animation = tween(1400, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "phase"
    )

    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(height),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val totalWidth = size.width
            val totalHeight = size.height
            val barWidth = (totalWidth / (barCount * 1.5f)).coerceAtLeast(3f)
            val spacing = (totalWidth - (barWidth * barCount)) / (barCount - 1).coerceAtLeast(1)

            val gradient = Brush.verticalGradient(
                colors = listOf(
                    AccentPink,
                    AccentPurple,
                    AccentNeonBlue,
                    AccentCyan
                )
            )

            for (i in 0 until barCount) {
                val x = i * (barWidth + spacing)
                val base = if (isPlaying) {
                    val wave = (sin(phase + (i * 0.45f)) + 1.0f) * 0.4f
                    val wave2 = (sin((phase * 1.5f) - (i * 0.3f)) + 1.0f) * 0.25f
                    (wave + wave2 + (amplitude * 0.5f)).coerceIn(0.15f, 0.95f)
                } else {
                    0.08f
                }

                val barH = totalHeight * base
                val y = totalHeight - barH

                drawRoundRect(
                    brush = gradient,
                    topLeft = Offset(x, y),
                    size = Size(barWidth, barH),
                    cornerRadius = CornerRadius(barWidth / 2, barWidth / 2)
                )
            }
        }
    }
}

@Composable
fun GlassPulsingRings(
    isPlaying: Boolean,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "rings")
    val scale1 by infiniteTransition.animateFloat(
        initialValue = 0.8f,
        targetValue = 1.35f,
        animationSpec = infiniteRepeatable(
            animation = tween(2000, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "r1"
    )
    val alpha1 by infiniteTransition.animateFloat(
        initialValue = 0.6f,
        targetValue = 0f,
        animationSpec = infiniteRepeatable(
            animation = tween(2000, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "a1"
    )

    Canvas(modifier = modifier) {
        if (isPlaying) {
            drawCircle(
                color = AccentCyan.copy(alpha = alpha1),
                radius = (size.minDimension / 2f) * scale1
            )
            drawCircle(
                color = AccentNeonBlue.copy(alpha = alpha1 * 0.7f),
                radius = (size.minDimension / 2f) * (scale1 * 0.85f)
            )
        }
    }
}
