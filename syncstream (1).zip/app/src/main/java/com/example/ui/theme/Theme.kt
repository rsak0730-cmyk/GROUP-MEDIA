package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val SoundSyncDarkColorScheme = darkColorScheme(
    primary = AccentCyan,
    onPrimary = Color.Black,
    primaryContainer = Color(0x3300F5D4),
    onPrimaryContainer = Color.White,
    secondary = AccentNeonBlue,
    onSecondary = Color.Black,
    secondaryContainer = Color(0x3300BBF9),
    onSecondaryContainer = Color.White,
    tertiary = AccentPurple,
    onTertiary = Color.White,
    background = GlassBackgroundDeep,
    onBackground = TextPrimary,
    surface = GlassBackgroundSurface,
    onSurface = TextPrimary,
    surfaceVariant = Color(0x24FFFFFF),
    onSurfaceVariant = TextSecondary,
    outline = GlassBorderThick,
    outlineVariant = GlassBorderSubtle
)

@Composable
fun SoundSyncTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = SoundSyncDarkColorScheme,
        typography = Typography,
        content = content
    )
}
