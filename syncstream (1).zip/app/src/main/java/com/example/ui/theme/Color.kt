package com.example.ui.theme

import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

// Glassmorphic Audio Palette
val GlassBackgroundDeep = Color(0xFF090B10)
val GlassBackgroundMid = Color(0xFF0F1524)
val GlassBackgroundSurface = Color(0xFF161E36)

// Translucent Glass Surfaces
val GlassSurface = Color(0x24FFFFFF)
val GlassSurfaceLight = Color(0x38FFFFFF)
val GlassSurfaceSubtle = Color(0x14FFFFFF)
val GlassSurfaceActive = Color(0x4DFFFFFF)

// Solid & Crisp Thick White Borders
val GlassBorderThick = Color(0xFFFFFFFF)
val GlassBorderMedium = Color(0xEEFFFFFF)
val GlassBorderSubtle = Color(0xB3FFFFFF)

// Vibrant Glow Accents
val AccentCyan = Color(0xFF00F5D4)
val AccentPurple = Color(0xFF9D4EDD)
val AccentNeonBlue = Color(0xFF00BBF9)
val AccentPink = Color(0xFFF72585)
val AccentAmber = Color(0xFFFFB703)
val AccentGreen = Color(0xFF38B000)

// Text Colors
val TextPrimary = Color(0xFFFFFFFF)
val TextSecondary = Color(0xCCFFFFFF)
val TextTertiary = Color(0x8AFFFFFF)

// Gradients
val GlassAuroraGradient = Brush.verticalGradient(
    colors = listOf(
        Color(0xFF0A0D18),
        Color(0xFF0F172E),
        Color(0xFF161B30),
        Color(0xFF090B10)
    )
)

val GlassGlowGradient = Brush.radialGradient(
    colors = listOf(
        Color(0x3300F5D4),
        Color(0x1A00BBF9),
        Color(0x00000000)
    )
)

val GlassAccentGradient = Brush.horizontalGradient(
    colors = listOf(
        AccentCyan,
        AccentNeonBlue,
        AccentPurple
    )
)
