package com.example.ui

import android.app.Application
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.net.Uri
import androidx.compose.ui.graphics.ImageBitmap
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.audio.AudioSyncEngine
import com.example.model.AudioSourceType
import com.example.model.AudioTrackItem
import com.example.model.GroupInfo
import com.example.model.InstalledAppItem
import com.example.model.MemberDevice
import com.example.model.PlaybackState
import com.example.model.SampleAudioTracks
import com.example.model.SyncAudioState
import com.example.network.NetworkUtils
import com.example.network.SoundSyncClient
import com.example.network.SoundSyncHostServer
import com.example.qr.QrCodeGenerator
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

enum class AppScreen {
    HOME,
    CREATE_GROUP,
    JOIN_GROUP,
    MEMBER_SYNCED
}

data class CheerEvent(
    val id: Long = System.currentTimeMillis(),
    val emoji: String,
    val sender: String
)

data class SoundSyncUiState(
    val currentScreen: AppScreen = AppScreen.HOME,
    val isHost: Boolean = false,
    val groupInfo: GroupInfo? = null,
    val qrImageBitmap: ImageBitmap? = null,
    val connectedMembers: List<MemberDevice> = emptyList(),
    val audioState: SyncAudioState = SyncAudioState(),
    val audioTracks: List<AudioTrackItem> = SampleAudioTracks,
    val selectedTrackIndex: Int = 0,
    val installedApps: List<InstalledAppItem> = emptyList(),
    val isAppSelectorVisible: Boolean = false,
    val clientConnectionStatus: String? = null,
    val isClientConnected: Boolean = false,
    val clientLatencyMs: Long = 0L,
    val visualizerAmplitude: Float = 0.2f,
    val currentSynthTick: Int = 0,
    val activeCheers: List<CheerEvent> = emptyList(),
    val localIpAddress: String = "192.168.1.100",
    val wifiSsid: String = "Wi-Fi Network",
    val showManualIpDialog: Boolean = false,
    val acousticOffsetMs: Int = 0,
    val statusMessage: String? = null
)

class SoundSyncViewModel(application: Application) : AndroidViewModel(application) {

    private val _uiState = MutableStateFlow(SoundSyncUiState())
    val uiState: StateFlow<SoundSyncUiState> = _uiState.asStateFlow()

    private var hostServer: SoundSyncHostServer? = null
    private var syncClient: SoundSyncClient? = null

    val audioEngine: AudioSyncEngine = AudioSyncEngine(
        context = application.applicationContext,
        onAmplitudeChanged = { amp ->
            _uiState.value = _uiState.value.copy(visualizerAmplitude = amp)
        },
        onSynthTick = { tick, freq ->
            _uiState.value = _uiState.value.copy(currentSynthTick = tick)
            if (_uiState.value.isHost) {
                hostServer?.broadcastAudioTone(freq, 200L, tick)
            }
        }
    )

    init {
        refreshNetworkInfo()
        loadInstalledApps()
    }

    fun refreshNetworkInfo() {
        val app = getApplication<Application>()
        val ip = NetworkUtils.getLocalIpAddress(app)
        val ssid = NetworkUtils.getWifiSsid(app)
        _uiState.value = _uiState.value.copy(
            localIpAddress = ip,
            wifiSsid = ssid
        )
    }

    fun navigateTo(screen: AppScreen) {
        _uiState.value = _uiState.value.copy(currentScreen = screen)
    }

    // ==========================================
    // 1. HOST MODE (Create Group)
    // ==========================================
    fun createGroup() {
        refreshNetworkInfo()
        val app = getApplication<Application>()
        val deviceName = NetworkUtils.getDeviceName()
        val ip = _uiState.value.localIpAddress
        val ssid = _uiState.value.wifiSsid
        val groupId = "SYNC-${(1000..9999).random()}"

        val group = GroupInfo(
            groupId = groupId,
            hostName = deviceName,
            hostIp = ip,
            port = 8888,
            streamPort = 8889,
            ssid = ssid
        )

        // Generate QR code bitmap
        val qrJson = group.toJson()
        val qrBitmap = QrCodeGenerator.generateQrImageBitmap(qrJson, 600)

        // Initialize Host Server
        hostServer?.stopServer()
        hostServer = SoundSyncHostServer(
            port = 8888,
            onMembersChanged = { members ->
                _uiState.value = _uiState.value.copy(connectedMembers = members)
            },
            onCheerReceived = { emoji, sender ->
                triggerCheer(emoji, sender)
            },
            onLogMessage = { msg ->
                _uiState.value = _uiState.value.copy(statusMessage = msg)
            }
        )
        hostServer?.startServer(groupId, deviceName)

        _uiState.value = _uiState.value.copy(
            currentScreen = AppScreen.CREATE_GROUP,
            isHost = true,
            groupInfo = group,
            qrImageBitmap = qrBitmap,
            connectedMembers = emptyList(),
            audioState = SyncAudioState(
                playbackState = PlaybackState.STOPPED,
                currentTrackTitle = _uiState.value.audioTracks.firstOrNull()?.title ?: "Neon Horizon",
                currentTrackArtist = _uiState.value.audioTracks.firstOrNull()?.artist ?: "SoundSync",
                masterVolume = 0.9f
            )
        )
    }

    // ==========================================
    // 2. CLIENT MODE (Join Group via QR or IP)
    // ==========================================
    fun startJoinGroup() {
        _uiState.value = _uiState.value.copy(
            currentScreen = AppScreen.JOIN_GROUP,
            isHost = false,
            clientConnectionStatus = "Scanning for Host QR Code..."
        )
    }

    fun onQrScanned(rawResult: String) {
        val group = GroupInfo.fromJson(rawResult)
        if (group != null) {
            connectToHost(group.hostIp, group.port, group)
        } else {
            // Check if user scanned plain IP
            if (rawResult.matches(Regex("\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}(:\\d+)?"))) {
                val parts = rawResult.split(":")
                val ip = parts[0]
                val port = if (parts.size > 1) parts[1].toIntOrNull() ?: 8888 else 8888
                connectToHost(ip, port, GroupInfo("GRP-MANUAL", "Host ($ip)", ip, port))
            } else {
                _uiState.value = _uiState.value.copy(
                    statusMessage = "Invalid QR code format. Please scan a SoundSync Host QR."
                )
            }
        }
    }

    fun connectToHost(ip: String, port: Int, groupInfo: GroupInfo? = null) {
        val clientName = NetworkUtils.getDeviceName()
        _uiState.value = _uiState.value.copy(
            groupInfo = groupInfo ?: GroupInfo("GRP-CONNECT", "Host ($ip)", ip, port),
            clientConnectionStatus = "Connecting to $ip:$port..."
        )

        syncClient?.disconnect()
        syncClient = SoundSyncClient(
            onStateUpdated = { newState ->
                _uiState.value = _uiState.value.copy(audioState = newState)
                handleClientAudioSync(newState)
            },
            onToneReceived = { freq, durationMs, tick ->
                _uiState.value = _uiState.value.copy(currentSynthTick = tick)
                audioEngine.playSingleTone(freq, durationMs)
            },
            onCheerReceived = { emoji, sender ->
                triggerCheer(emoji, sender)
            },
            onConnectionStateChanged = { isConnected, errorMsg ->
                _uiState.value = _uiState.value.copy(
                    isClientConnected = isConnected,
                    clientConnectionStatus = if (isConnected) "Connected as Synced Speaker" else errorMsg,
                    currentScreen = if (isConnected) AppScreen.MEMBER_SYNCED else _uiState.value.currentScreen
                )
            },
            onLatencyUpdated = { latency ->
                _uiState.value = _uiState.value.copy(clientLatencyMs = latency)
            }
        )

        syncClient?.connectToHost(ip, port, clientName)
    }

    private fun handleClientAudioSync(state: SyncAudioState) {
        when (state.playbackState) {
            PlaybackState.PLAYING -> {
                when (state.sourceType) {
                    AudioSourceType.SYNTHESIZER,
                    AudioSourceType.BUILTIN_TRACK -> {
                        val currentTrack = _uiState.value.audioTracks.find { it.title == state.currentTrackTitle }
                        val preset = currentTrack?.synthPresetName ?: "SYNTH_NEON"
                        audioEngine.startSynthPlayback(preset) {}
                    }
                    AudioSourceType.LIVE_MIC,
                    AudioSourceType.EXTERNAL_APP,
                    AudioSourceType.LOCAL_FILE -> {
                        // Synced tone or stream
                    }
                }
            }
            PlaybackState.PAUSED,
            PlaybackState.STOPPED -> {
                audioEngine.stopSynth()
            }
        }
    }

    // ==========================================
    // AUDIO CONTROLS (Host & Local)
    // ==========================================
    fun togglePlayPause() {
        val current = _uiState.value.audioState
        val nextState = if (current.playbackState == PlaybackState.PLAYING) {
            PlaybackState.PAUSED
        } else {
            PlaybackState.PLAYING
        }

        val updated = current.copy(playbackState = nextState)
        _uiState.value = _uiState.value.copy(audioState = updated)

        if (_uiState.value.isHost) {
            hostServer?.broadcastState(updated)
            if (nextState == PlaybackState.PLAYING) {
                val track = _uiState.value.audioTracks.getOrNull(_uiState.value.selectedTrackIndex)
                val preset = track?.synthPresetName ?: "SYNTH_NEON"
                audioEngine.startSynthPlayback(preset) {}
            } else {
                audioEngine.stopSynth()
            }
        }
    }

    fun selectTrack(index: Int) {
        val tracks = _uiState.value.audioTracks
        if (index in tracks.indices) {
            val track = tracks[index]
            val updated = _uiState.value.audioState.copy(
                currentTrackTitle = track.title,
                currentTrackArtist = track.artist,
                currentTrackDurationMs = track.durationMs,
                sourceType = AudioSourceType.BUILTIN_TRACK
            )
            _uiState.value = _uiState.value.copy(
                selectedTrackIndex = index,
                audioState = updated
            )
            if (_uiState.value.isHost) {
                hostServer?.broadcastState(updated)
                if (updated.playbackState == PlaybackState.PLAYING) {
                    audioEngine.startSynthPlayback(track.synthPresetName ?: "SYNTH_NEON") {}
                }
            }
        }
    }

    fun setMasterVolume(vol: Float) {
        val updated = _uiState.value.audioState.copy(masterVolume = vol)
        _uiState.value = _uiState.value.copy(audioState = updated)
        audioEngine.localVolume = vol
        if (_uiState.value.isHost) {
            hostServer?.broadcastState(updated)
        } else {
            syncClient?.sendVolume(vol)
        }
    }

    fun setAcousticOffset(offsetMs: Int) {
        _uiState.value = _uiState.value.copy(acousticOffsetMs = offsetMs)
        audioEngine.acousticLatencyOffsetMs = offsetMs
    }

    fun toggleMicBroadcast() {
        val current = _uiState.value.audioState
        val isBroadcasting = !current.isMicBroadcasting
        val updated = current.copy(
            isMicBroadcasting = isBroadcasting,
            sourceType = if (isBroadcasting) AudioSourceType.LIVE_MIC else AudioSourceType.BUILTIN_TRACK
        )
        _uiState.value = _uiState.value.copy(audioState = updated)

        if (_uiState.value.isHost) {
            hostServer?.broadcastState(updated)
            if (isBroadcasting) {
                audioEngine.startLiveMicBroadcast { chunk ->
                    // Chunk broadcast
                }
            } else {
                audioEngine.stopMicBroadcast()
            }
        }
    }

    // ==========================================
    // EXTERNAL APP MEDIA ROUTING
    // ==========================================
    fun loadInstalledApps() {
        viewModelScope.launch(Dispatchers.IO) {
            val pm = getApplication<Application>().packageManager
            val intent = Intent(Intent.ACTION_MAIN, null).apply {
                addCategory(Intent.CATEGORY_LAUNCHER)
            }
            val resolveInfos = pm.queryIntentActivities(intent, 0)
            val appList = resolveInfos.mapNotNull { resolveInfo ->
                try {
                    val pkg = resolveInfo.activityInfo.packageName
                    val name = resolveInfo.loadLabel(pm).toString()
                    val icon = resolveInfo.loadIcon(pm)
                    val isMedia = pkg.contains("music", ignoreCase = true) ||
                            pkg.contains("audio", ignoreCase = true) ||
                            pkg.contains("spotify", ignoreCase = true) ||
                            pkg.contains("youtube", ignoreCase = true) ||
                            pkg.contains("soundcloud", ignoreCase = true) ||
                            pkg.contains("player", ignoreCase = true) ||
                            pkg.contains("radio", ignoreCase = true)

                    InstalledAppItem(
                        packageName = pkg,
                        appName = name,
                        icon = icon,
                        isMediaCategory = isMedia
                    )
                } catch (_: Exception) {
                    null
                }
            }.sortedWith(
                compareByDescending<InstalledAppItem> { it.isMediaCategory }
                    .thenBy { it.appName }
            )

            withContext(Dispatchers.Main) {
                _uiState.value = _uiState.value.copy(installedApps = appList)
            }
        }
    }

    fun setAppSelectorVisible(visible: Boolean) {
        _uiState.value = _uiState.value.copy(isAppSelectorVisible = visible)
    }

    fun selectExternalApp(app: InstalledAppItem) {
        val updated = _uiState.value.audioState.copy(
            selectedAppPackage = app.packageName,
            selectedAppName = app.appName,
            currentTrackTitle = "Streaming: ${app.appName}",
            currentTrackArtist = "External App Audio Channel",
            sourceType = AudioSourceType.EXTERNAL_APP,
            playbackState = PlaybackState.PLAYING
        )
        _uiState.value = _uiState.value.copy(
            audioState = updated,
            isAppSelectorVisible = false
        )

        if (_uiState.value.isHost) {
            hostServer?.broadcastState(updated)
            // Launch the selected app so user can start playing media
            try {
                val pm = getApplication<Application>().packageManager
                val launchIntent = pm.getLaunchIntentForPackage(app.packageName)
                launchIntent?.let {
                    it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    getApplication<Application>().startActivity(it)
                }
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(statusMessage = "Could not launch ${app.appName}: ${e.message}")
            }
        }
    }

    // ==========================================
    // INTERACTIVE CHEERS / REACTIONS
    // ==========================================
    fun sendCheer(emoji: String) {
        val sender = NetworkUtils.getDeviceName()
        triggerCheer(emoji, sender)

        if (_uiState.value.isHost) {
            hostServer?.broadcastCheer(emoji, sender)
        } else {
            syncClient?.sendCheer(emoji, sender)
        }
    }

    private fun triggerCheer(emoji: String, sender: String) {
        val event = CheerEvent(emoji = emoji, sender = sender)
        val list = _uiState.value.activeCheers + event
        _uiState.value = _uiState.value.copy(activeCheers = list.takeLast(6))

        // Play feedback tone
        val tone = when (emoji) {
            "🔥" -> 660.0
            "🎉" -> 880.0
            "❤️" -> 523.25
            "🔊" -> 350.0
            else -> 440.0
        }
        audioEngine.playSingleTone(tone, 120L)
    }

    fun setShowManualIpDialog(show: Boolean) {
        _uiState.value = _uiState.value.copy(showManualIpDialog = show)
    }

    fun clearStatusMessage() {
        _uiState.value = _uiState.value.copy(statusMessage = null)
    }

    fun disconnectAndReset() {
        audioEngine.stopAll()
        hostServer?.stopServer()
        syncClient?.disconnect()
        _uiState.value = _uiState.value.copy(
            currentScreen = AppScreen.HOME,
            isHost = false,
            groupInfo = null,
            qrImageBitmap = null,
            connectedMembers = emptyList(),
            isClientConnected = false,
            audioState = SyncAudioState()
        )
    }

    override fun onCleared() {
        super.onCleared()
        audioEngine.stopAll()
        hostServer?.stopServer()
        syncClient?.disconnect()
    }
}
