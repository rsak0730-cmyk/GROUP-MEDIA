package com.example.network

import android.util.Log
import com.example.model.MemberDevice
import com.example.model.PlaybackState
import com.example.model.SyncAudioState
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.PrintWriter
import java.net.ServerSocket
import java.net.Socket
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.CopyOnWriteArrayList

class SoundSyncHostServer(
    val port: Int = 8888,
    private val onMembersChanged: (List<MemberDevice>) -> Unit,
    private val onCheerReceived: (String, String) -> Unit,
    private val onLogMessage: (String) -> Unit
) {
    private val tag = "SoundSyncHost"
    private var serverSocket: ServerSocket? = null
    private var serverJob: Job? = null
    private val scope = CoroutineScope(Dispatchers.IO)

    private val connectedClients = ConcurrentHashMap<String, ClientHandler>()
    val memberList = CopyOnWriteArrayList<MemberDevice>()

    private var currentAudioState = SyncAudioState()

    fun startServer(groupId: String, hostName: String) {
        stopServer()
        serverJob = scope.launch {
            try {
                serverSocket = ServerSocket(port).apply {
                    reuseAddress = true
                }
                onLogMessage("Host Server listening on port $port")

                while (isActive && serverSocket?.isClosed == false) {
                    try {
                        val clientSocket = serverSocket?.accept() ?: break
                        launch {
                            handleNewConnection(clientSocket, groupId, hostName)
                        }
                    } catch (e: Exception) {
                        if (isActive) {
                            Log.e(tag, "Error accepting client: ${e.message}")
                        }
                    }
                }
            } catch (e: Exception) {
                Log.e(tag, "Failed to start server on port $port: ${e.message}")
                onLogMessage("Server error: ${e.message}")
            }
        }
    }

    private fun handleNewConnection(socket: Socket, groupId: String, hostName: String) {
        val clientIp = socket.inetAddress.hostAddress ?: "unknown"
        val clientId = "dev_${System.currentTimeMillis() % 100000}_${clientIp.replace(".", "_")}"
        
        try {
            val reader = BufferedReader(InputStreamReader(socket.getInputStream()))
            val writer = PrintWriter(socket.getOutputStream(), true)

            val handler = ClientHandler(clientId, socket, reader, writer)
            connectedClients[clientId] = handler

            // Read first line (handshake)
            val firstLine = reader.readLine()
            var deviceName = "Speaker ${memberList.size + 1}"
            if (firstLine != null) {
                try {
                    val obj = JSONObject(firstLine)
                    if (obj.has("deviceName")) {
                        deviceName = obj.getString("deviceName")
                    }
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }

            val newMember = MemberDevice(
                id = clientId,
                deviceName = deviceName,
                ipAddress = clientIp,
                latencyMs = 12L,
                volume = 1.0f
            )
            memberList.add(newMember)
            onMembersChanged(memberList.toList())
            onLogMessage("Connected: $deviceName ($clientIp)")

            // Send ACK with initial state
            val ackObj = JSONObject().apply {
                put("action", "JOIN_ACK")
                put("groupId", groupId)
                put("hostName", hostName)
                put("memberId", clientId)
                put("state", currentAudioState.playbackState.name)
                put("trackTitle", currentAudioState.currentTrackTitle)
                put("artist", currentAudioState.currentTrackArtist)
                put("durationMs", currentAudioState.currentTrackDurationMs)
                put("positionMs", currentAudioState.playbackPositionMs)
                put("masterVolume", currentAudioState.masterVolume.toDouble())
                put("sourceType", currentAudioState.sourceType.name)
                put("masterClockNtp", System.currentTimeMillis())
            }
            handler.sendMessage(ackObj.toString())

            // Client communication loop
            var line: String?
            while (socket.isConnected && !socket.isClosed) {
                line = reader.readLine() ?: break
                handleClientMessage(clientId, line, handler)
            }
        } catch (e: Exception) {
            Log.d(tag, "Client $clientId disconnected: ${e.message}")
        } finally {
            connectedClients.remove(clientId)
            memberList.removeAll { it.id == clientId }
            onMembersChanged(memberList.toList())
            onLogMessage("Disconnected: $clientIp")
            try { socket.close() } catch (_: Exception) {}
        }
    }

    private fun handleClientMessage(clientId: String, message: String, handler: ClientHandler) {
        try {
            val obj = JSONObject(message)
            val action = obj.optString("action")

            when (action) {
                "SYNC_PING" -> {
                    val t0 = obj.optLong("t0", 0L)
                    val t1 = System.currentTimeMillis()
                    val pongObj = JSONObject().apply {
                        put("action", "SYNC_PONG")
                        put("t0", t0)
                        put("t1", t1)
                        put("t2", System.currentTimeMillis())
                    }
                    handler.sendMessage(pongObj.toString())
                }
                "PING_REPORT" -> {
                    val rtt = obj.optLong("rtt", 10L)
                    val memberIndex = memberList.indexOfFirst { it.id == clientId }
                    if (memberIndex >= 0) {
                        val updated = memberList[memberIndex].copy(latencyMs = rtt)
                        memberList[memberIndex] = updated
                        onMembersChanged(memberList.toList())
                    }
                }
                "CHEER" -> {
                    val emoji = obj.optString("emoji", "🎵")
                    val senderName = obj.optString("senderName", "Member")
                    onCheerReceived(emoji, senderName)
                    // Broadcast cheer to other peers too
                    broadcast(message, excludeClientId = clientId)
                }
                "CLIENT_VOLUME" -> {
                    val vol = obj.optDouble("volume", 1.0).toFloat()
                    val memberIndex = memberList.indexOfFirst { it.id == clientId }
                    if (memberIndex >= 0) {
                        memberList[memberIndex] = memberList[memberIndex].copy(volume = vol)
                        onMembersChanged(memberList.toList())
                    }
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun broadcastState(state: SyncAudioState) {
        currentAudioState = state
        val obj = JSONObject().apply {
            put("action", "SYNC_STATE")
            put("state", state.playbackState.name)
            put("trackTitle", state.currentTrackTitle)
            put("artist", state.currentTrackArtist)
            put("durationMs", state.currentTrackDurationMs)
            put("positionMs", state.playbackPositionMs)
            put("masterVolume", state.masterVolume.toDouble())
            put("sourceType", state.sourceType.name)
            put("selectedAppName", state.selectedAppName ?: "")
            put("isMicBroadcasting", state.isMicBroadcasting)
            put("timestampSentMs", System.currentTimeMillis())
            put("masterClockNtp", System.currentTimeMillis())
        }
        broadcast(obj.toString())
    }

    fun broadcastAudioTone(freq: Double, durationMs: Long, beatTick: Int) {
        val obj = JSONObject().apply {
            put("action", "AUDIO_TONE")
            put("freq", freq)
            put("durationMs", durationMs)
            put("beatTick", beatTick)
            put("masterClockNtp", System.currentTimeMillis())
        }
        broadcast(obj.toString())
    }

    fun broadcastCheer(emoji: String, hostName: String) {
        val obj = JSONObject().apply {
            put("action", "CHEER")
            put("emoji", emoji)
            put("senderName", hostName)
        }
        broadcast(obj.toString())
    }

    private fun broadcast(message: String, excludeClientId: String? = null) {
        scope.launch {
            connectedClients.forEach { (id, client) ->
                if (id != excludeClientId) {
                    client.sendMessage(message)
                }
            }
        }
    }

    fun stopServer() {
        try {
            serverJob?.cancel()
            connectedClients.values.forEach { it.close() }
            connectedClients.clear()
            memberList.clear()
            serverSocket?.close()
            serverSocket = null
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private class ClientHandler(
        val clientId: String,
        val socket: Socket,
        val reader: BufferedReader,
        val writer: PrintWriter
    ) {
        fun sendMessage(msg: String) {
            try {
                synchronized(writer) {
                    writer.println(msg)
                    writer.flush()
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }

        fun close() {
            try {
                socket.close()
            } catch (_: Exception) {}
        }
    }
}
