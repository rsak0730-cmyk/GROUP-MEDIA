package com.example.network

import android.util.Log
import com.example.model.AudioSourceType
import com.example.model.PlaybackState
import com.example.model.SyncAudioState
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.PrintWriter
import java.net.InetSocketAddress
import java.net.Socket

class SoundSyncClient(
    private val onStateUpdated: (SyncAudioState) -> Unit,
    private val onToneReceived: (Double, Long, Int) -> Unit,
    private val onCheerReceived: (String, String) -> Unit,
    private val onConnectionStateChanged: (Boolean, String?) -> Unit,
    private val onLatencyUpdated: (Long) -> Unit
) {
    private val tag = "SoundSyncClient"
    private var socket: Socket? = null
    private var writer: PrintWriter? = null
    private var reader: BufferedReader? = null
    private var clientJob: Job? = null
    private var pingJob: Job? = null
    private val scope = CoroutineScope(Dispatchers.IO)

    var clockOffsetMs: Long = 0L
        private set
    var averageLatencyMs: Long = 0L
        private set

    fun connectToHost(hostIp: String, port: Int, clientDeviceName: String) {
        disconnect()
        clientJob = scope.launch {
            try {
                onConnectionStateChanged(false, "Connecting to $hostIp:$port...")
                val newSocket = Socket()
                newSocket.connect(InetSocketAddress(hostIp, port), 5000)
                socket = newSocket

                val outWriter = PrintWriter(newSocket.getOutputStream(), true)
                val inReader = BufferedReader(InputStreamReader(newSocket.getInputStream()))
                writer = outWriter
                reader = inReader

                // Send Handshake
                val handshakeObj = JSONObject().apply {
                    put("action", "CLIENT_JOIN")
                    put("deviceName", clientDeviceName)
                    put("clientTime", System.currentTimeMillis())
                }
                outWriter.println(handshakeObj.toString())
                outWriter.flush()

                onConnectionStateChanged(true, null)

                // Start background ping loop to maintain clock sync
                startPingLoop()

                // Read loop
                while (isActive && newSocket.isConnected && !newSocket.isClosed) {
                    val line = inReader.readLine() ?: break
                    handleServerMessage(line)
                }
            } catch (e: Exception) {
                Log.e(tag, "Client connection failed: ${e.message}")
                onConnectionStateChanged(false, e.message ?: "Connection failed")
            } finally {
                disconnect()
            }
        }
    }

    private fun startPingLoop() {
        pingJob?.cancel()
        pingJob = scope.launch {
            while (isActive && socket?.isConnected == true) {
                sendPing()
                delay(2500)
            }
        }
    }

    private fun sendPing() {
        try {
            val t0 = System.currentTimeMillis()
            val pingObj = JSONObject().apply {
                put("action", "SYNC_PING")
                put("t0", t0)
            }
            writer?.println(pingObj.toString())
            writer?.flush()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun handleServerMessage(message: String) {
        try {
            val obj = JSONObject(message)
            val action = obj.optString("action")

            when (action) {
                "JOIN_ACK" -> {
                    val stateStr = obj.optString("state", "STOPPED")
                    val state = try { PlaybackState.valueOf(stateStr) } catch (_: Exception) { PlaybackState.STOPPED }
                    val sourceTypeStr = obj.optString("sourceType", "BUILTIN_TRACK")
                    val sourceType = try { AudioSourceType.valueOf(sourceTypeStr) } catch (_: Exception) { AudioSourceType.BUILTIN_TRACK }

                    val newState = SyncAudioState(
                        playbackState = state,
                        currentTrackTitle = obj.optString("trackTitle", "Synced Stream"),
                        currentTrackArtist = obj.optString("artist", "SoundSync Host"),
                        currentTrackDurationMs = obj.optLong("durationMs", 180000L),
                        playbackPositionMs = obj.optLong("positionMs", 0L),
                        masterVolume = obj.optDouble("masterVolume", 0.85).toFloat(),
                        sourceType = sourceType,
                        masterClockNtp = obj.optLong("masterClockNtp", System.currentTimeMillis())
                    )
                    onStateUpdated(newState)
                }
                "SYNC_PONG" -> {
                    val t0 = obj.optLong("t0", 0L)
                    val t1 = obj.optLong("t1", 0L)
                    val t2 = obj.optLong("t2", 0L)
                    val t3 = System.currentTimeMillis()

                    if (t0 > 0) {
                        val roundTrip = (t3 - t0) - (t2 - t1)
                        val offset = ((t1 - t0) + (t2 - t3)) / 2
                        clockOffsetMs = offset
                        averageLatencyMs = (roundTrip / 2).coerceAtLeast(1)
                        onLatencyUpdated(averageLatencyMs)

                        // Report back to host
                        val reportObj = JSONObject().apply {
                            put("action", "PING_REPORT")
                            put("rtt", averageLatencyMs)
                        }
                        writer?.println(reportObj.toString())
                    }
                }
                "SYNC_STATE" -> {
                    val stateStr = obj.optString("state", "STOPPED")
                    val state = try { PlaybackState.valueOf(stateStr) } catch (_: Exception) { PlaybackState.STOPPED }
                    val sourceTypeStr = obj.optString("sourceType", "BUILTIN_TRACK")
                    val sourceType = try { AudioSourceType.valueOf(sourceTypeStr) } catch (_: Exception) { AudioSourceType.BUILTIN_TRACK }

                    val newState = SyncAudioState(
                        playbackState = state,
                        currentTrackTitle = obj.optString("trackTitle", "Synced Stream"),
                        currentTrackArtist = obj.optString("artist", "SoundSync Host"),
                        currentTrackDurationMs = obj.optLong("durationMs", 180000L),
                        playbackPositionMs = obj.optLong("positionMs", 0L),
                        masterVolume = obj.optDouble("masterVolume", 0.85).toFloat(),
                        sourceType = sourceType,
                        selectedAppName = obj.optString("selectedAppName", ""),
                        isMicBroadcasting = obj.optBoolean("isMicBroadcasting", false),
                        timestampSentMs = obj.optLong("timestampSentMs", System.currentTimeMillis()),
                        masterClockNtp = obj.optLong("masterClockNtp", System.currentTimeMillis())
                    )
                    onStateUpdated(newState)
                }
                "AUDIO_TONE" -> {
                    val freq = obj.optDouble("freq", 440.0)
                    val durationMs = obj.optLong("durationMs", 150L)
                    val beatTick = obj.optInt("beatTick", 0)
                    onToneReceived(freq, durationMs, beatTick)
                }
                "CHEER" -> {
                    val emoji = obj.optString("emoji", "🎵")
                    val senderName = obj.optString("senderName", "Friend")
                    onCheerReceived(emoji, senderName)
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun sendCheer(emoji: String, clientName: String) {
        scope.launch {
            try {
                val cheerObj = JSONObject().apply {
                    put("action", "CHEER")
                    put("emoji", emoji)
                    put("senderName", clientName)
                }
                writer?.println(cheerObj.toString())
                writer?.flush()
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    fun sendVolume(volume: Float) {
        scope.launch {
            try {
                val volObj = JSONObject().apply {
                    put("action", "CLIENT_VOLUME")
                    put("volume", volume.toDouble())
                }
                writer?.println(volObj.toString())
                writer?.flush()
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    fun disconnect() {
        try {
            pingJob?.cancel()
            clientJob?.cancel()
            socket?.close()
            socket = null
            reader = null
            writer = null
            onConnectionStateChanged(false, null)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
}
